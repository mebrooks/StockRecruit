stopifnot(require("testthat"),
          require("StockRecruitSET"))

context("weight")


set.seed(1)