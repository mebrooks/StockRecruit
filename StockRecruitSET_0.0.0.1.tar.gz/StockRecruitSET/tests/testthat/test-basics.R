stopifnot(require("testthat"),
          require("StockRecruitSET"))
